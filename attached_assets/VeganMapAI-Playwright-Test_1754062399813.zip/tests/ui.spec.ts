
// tests/ui.spec.ts
import { test, expect } from '@playwright/test';

test('🌍 Началната страница зарежда картата', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#map')).toBeVisible();
});

test('💬 Агентът приема /помощ в чата', async ({ page }) => {
  await page.goto('/');
  const chatInput = page.locator('input[type="text"]'); // замени селектора според реалния ти чат
  await chatInput.fill('/помощ тест');
  await chatInput.press('Enter');

  const response = page.locator('.agent-response'); // селектор за отговор
  await expect(response).toContainText('GPT съвет');
});
