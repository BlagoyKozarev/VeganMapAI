
// agent-regression.test.ts
import { describe, it, expect } from 'vitest';
import { handleAgentChat } from './agent-gpt-helper';
import fs from 'fs';

const SNAPSHOT_FILE = './snapshots/agent-response.txt';

describe('🤖 GPT regression тест', () => {
  it('не се е променил отговорът на /помощ', async () => {
    const result = await handleAgentChat('/помощ тествам');

    const old = fs.existsSync(SNAPSHOT_FILE) ? fs.readFileSync(SNAPSHOT_FILE, 'utf-8') : null;
    if (!old) {
      fs.mkdirSync('./snapshots', { recursive: true });
      fs.writeFileSync(SNAPSHOT_FILE, result, 'utf-8');
      console.log("📸 Snapshot записан.");
    } else {
      expect(result).toBe(old);
    }
  });
});
