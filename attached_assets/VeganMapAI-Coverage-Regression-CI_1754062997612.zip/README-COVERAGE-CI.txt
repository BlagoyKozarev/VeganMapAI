
📄 Инструкции за Coverage + Regression + GitHub CI

1. ✅ Инсталирай `c8` за покритие:
   npm install -D c8

2. ✅ Добави следното в package.json scripts:
   "scripts": {
     "test": "vitest",
     "coverage": "c8 vitest run"
   }

3. ✅ Snapshot тест:
   - Постави `agent-regression.test.ts` в основната директория
   - При първо пускане ще се създаде ./snapshots/ с файл
   - Следващите пъти ще проверява за разлики

4. ✅ GitHub CI:
   - Постави `.yml` файла в `.github/workflows/test.yml`
   - Всеки push/pull към main ще пуска тестовете автоматично
